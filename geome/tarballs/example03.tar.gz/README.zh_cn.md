# 几何清理修复示例三

[![en-us](https://img.shields.io/badge/en-us-yellow.svg)](./README.md) [![中文-简体](https://img.shields.io/badge/%E4%B8%AD%E6%96%87-%E7%AE%80%E4%BD%93-red.svg)](./README.zh_cn.md)

### 该示例展示使用几何编辑的压印用法，具体实现如下： 

	1. 使用 AMCAX::GeomE::GeomImprint 下的 Imprint() 在两个形状之间执行相互压印


输出结果如下，依次是几何压印1，几何压印2，几何压印3：


<div align = center><img src="https://s2.loli.net/2025/02/26/QaBO4EorqetbIxn.png" width="400" height="300"></div>

<div align = center><img src="https://s2.loli.net/2025/02/27/CezfyaOiIhQwSPD.png" width="400" height="300"></div>

<div align = center><img src="https://s2.loli.net/2025/02/27/qiBrKfyspHxo92Q.png" width="400" height="300"></div>


